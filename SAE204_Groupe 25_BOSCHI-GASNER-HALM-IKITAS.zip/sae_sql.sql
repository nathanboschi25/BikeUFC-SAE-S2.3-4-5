DROP TABLE IF EXISTS
    est_decline_couleur,
    est_decline_taille,
    ligne_panier,
    est_dans_etat,
    ligne_commande,
    velo,
    type_velo, -- OK
    fournisseur, -- OK
    declinaison_couleur,
    declinaison_taille,
    etat, -- OK
    commande,
    utilisateur; -- OK

CREATE TABLE utilisateur(
    id_utilisateur INT NOT NULL AUTO_INCREMENT,
    login VARCHAR(255),
    email VARCHAR(255),
    nom VARCHAR(255),
    password VARCHAR(255),
    role VARCHAR(255),

    est_actif TINYINT(1),
    -- token_email VARCHAR(255,
    -- token_email_date DATE(),

    -- go_auth_token VARCHAR(255),
    -- go_username_token VARCHAR(255)
    PRIMARY KEY (id_utilisateur)
)ENGINE=InnoDB DEFAULT CHARSET utf8mb4;

CREATE TABLE commande(
   id_commande INT NOT NULL AUTO_INCREMENT,
   date_achat DATE,
   id_utilisateur INT NOT NULL,
   PRIMARY KEY(id_commande),
   FOREIGN KEY(id_utilisateur) REFERENCES utilisateur(id_utilisateur)
);

CREATE TABLE etat(
   id_etat INT NOT NULL AUTO_INCREMENT,
   libelle VARCHAR(255),
   PRIMARY KEY(id_etat)
);

CREATE TABLE declinaison_taille(
   id_taille INT NOT NULL AUTO_INCREMENT,
   libelle_taille VARCHAR(50),
   PRIMARY KEY(id_taille)
);

CREATE TABLE declinaison_couleur(
   cde_couleur INT NOT NULL AUTO_INCREMENT,
   libelle_couleur VARCHAR(255),
   PRIMARY KEY(cde_couleur)
);

CREATE TABLE fournisseur(
   id_fournisseur INT NOT NULL AUTO_INCREMENT,
   libelle_fournisseur VARCHAR(50),
   PRIMARY KEY(id_fournisseur)
);

CREATE TABLE type_velo(
   id_type INT NOT NULL AUTO_INCREMENT,
   libelle_type VARCHAR(255),
   PRIMARY KEY(id_type)
);

CREATE TABLE velo(
   id_velo INT NOT NULL AUTO_INCREMENT,
   libelle_velo VARCHAR(255),
   prix_velo DECIMAL(10,2),
   image_velo VARCHAR(255),
   stock INT,
   id_type INT NOT NULL,
   id_fournisseur INT NOT NULL,
   PRIMARY KEY(id_velo),
   FOREIGN KEY(id_type) REFERENCES type_velo(id_type),
   FOREIGN KEY(id_fournisseur) REFERENCES fournisseur(id_fournisseur)
);

CREATE TABLE ligne_commande(
   id_commande INT NOT NULL,
   id_velo INT,
   quantite INT,
   PRIMARY KEY(id_commande, id_velo),
   FOREIGN KEY(id_commande) REFERENCES commande(id_commande),
   FOREIGN KEY(id_velo) REFERENCES velo(id_velo)
);

CREATE TABLE est_dans_etat(
   id_commande INT NOT NULL,
   id_etat INT,
   PRIMARY KEY(id_commande, id_etat),
   FOREIGN KEY(id_commande) REFERENCES commande(id_commande),
   FOREIGN KEY(id_etat) REFERENCES etat(id_etat)
);

CREATE TABLE ligne_panier(
   id_utilisateur INT NOT NULL,
   id_velo INT,
   quantite INT,
   PRIMARY KEY(id_utilisateur, id_velo),
   FOREIGN KEY(id_utilisateur) REFERENCES utilisateur(id_utilisateur),
   FOREIGN KEY(id_velo) REFERENCES velo(id_velo)
);

CREATE TABLE est_decline_taille(
   id_velo INT,
   id_taille INT,
   incidence_prix DECIMAL(10,2),
   PRIMARY KEY(id_velo, id_taille),
   FOREIGN KEY(id_velo) REFERENCES velo(id_velo),
   FOREIGN KEY(id_taille) REFERENCES declinaison_taille(id_taille)
);

CREATE TABLE est_decline_couleur(
   id_velo INT,
   cde_couleur INT,
   incidence_prix DECIMAL(10,2),
   PRIMARY KEY(id_velo, cde_couleur),
   FOREIGN KEY(id_velo) REFERENCES velo(id_velo),
   FOREIGN KEY(cde_couleur) REFERENCES declinaison_couleur(cde_couleur)
);

INSERT INTO etat(libelle) VALUES ('En attente'), ('Expédié'), ('Validé'), ('Confirmé'), ('Annulé');
INSERT INTO type_velo(libelle_type) VALUES ('VTT'), ('ROUTE'), ('VILLE'), ('ELECTRIQUE'), ('ENFANTS');
INSERT INTO fournisseur(libelle_fournisseur) VALUES ('TREK'), ('LAPIERRE'), ('PEUGEOT'), ('SPECIALIZED'), ('CUBE');
INSERT INTO declinaison_taille(libelle_taille) VALUES ('S (160-170)'), ('M (171-176)'), ('L (177-185)'), ('XL (186-192)');
INSERT INTO utilisateur(login, email, password, role) VALUE ('client', 'client@clients.com', 'sha256$p0G37N7TRA0rCdB2$e16136a121e9c3e1965e7823b9d9f9bc348c6104fd607fcce5e6ef47702dcb99', 'ROLE_client');
INSERT INTO velo(libelle_velo, prix_velo, image_velo, stock, id_type, id_fournisseur) VALUES
            ('Slash 8 GX', 4499.00, 'Slash8GX.jpeg', 100, 1, 1),
            ('Madone SLR 9 7eG', 14699.00, 'MadoneSLR9.jpeg', 100, 2, 1),
            ('Dual Sport 3 Equipped', 1249.00,'DualSport3EQ.webp', 100, 3, 1),
            ('Powerfly FS 9 Equipped 2eG', 7299.00,'PowerflyFS9EQ.webp', 100, 4, 1),
            ('Domane+ LT 7 2eG', 7999.00,'DomanePlusLT7.jpeg', 100, 4, 1),
            ('Spicy CF 6.9 2022', 4599.00, 'SpicyCF6.9MY22.png', 100, 1, 2),
            ('Aircode DRS 9.0 2022', 8399.00, 'AircodeDRS9.0MY22.png', 100, 2, 2),
            ('e-Urban 3.4 2023', 2599.00, 'E-Urban3.4MY22.png', 100, 4, 2),
            ('R02 CARBONE ULTEGRA - 2019', 2999.00, 'peugeot-r02-carbone-ultegra.jpg', 100, 2, 3),
            ('Epic Comp', 5200.00, 'EPIC-COMP.webp', 100, 1, 4),
            ('Sirrus 2.0 - Équipé', 1100.00, '90921-82_SIRRUS-20-EQ-FSTGRN-BLKREFL_HERO.webp', 100, 3, 4),
            ('Aethos Expert', 7000.00, '97222-30_AETHOS-EXPERT-OIL-FLKSIL_HERO1.webp', 100, 2, 4),
            ('TRAVEL SLX', 2199.00, 'travel.jpg', 100, 3, 5);